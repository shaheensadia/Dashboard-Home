export const CHART_COLORS = {
  primary: "#C77DFF",
  secondary: "#FF6B6B",
  success: "#38B000",
  info: "#4D96FF",
  warning: "#FFD93D",
  orange: "#e67e22",
  blue: "#3498db",
  green: "#2ecc71",
};

export const STATS_DATA = [
  { title: "Total Sales", value: "$182,450" },
  { title: "Total Clients", value: "1,437" },
  { title: "Total Products", value: "674" },
  { title: "Stock", value: "12,845" },
];

export const LINE_CHART_DATA = {
  labels: [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
  ],
  datasets: [
    {
      label: "Sales",
      data: [4200, 3900, 5100, 4600, 5300, 7200, 6000, 3000, 6800, 6200, 7000, 7400],
      borderColor: CHART_COLORS.primary,
      backgroundColor: "rgba(199, 125, 255, 0.3)",
      fill: true,
      tension: 0.4,
      pointBorderColor: "#fff",
      pointBackgroundColor: CHART_COLORS.primary,
      pointBorderWidth: 2,
    },
  ],
};

export const PIE_CHART_DATA = {
  categoryDistribution: {
    labels: [
      "Smartphones",
      "Laptops", 
      "Furniture",
      "Beauty & Personal Care",
      "Gaming Accessories",
    ],
    datasets: [
      {
        data: [30, 25, 18, 15, 13],
        backgroundColor: [
          CHART_COLORS.secondary,
          CHART_COLORS.info,
          CHART_COLORS.warning,
          CHART_COLORS.success,
          CHART_COLORS.primary,
        ],
      },
    ],
  },
  orderStatus: {
    labels: ["Processing", "Pending", "Canceled", "Delivered"],
    datasets: [
      {
        data: [18, 24, 12, 47],
        backgroundColor: [
          CHART_COLORS.secondary,
          CHART_COLORS.info,
          CHART_COLORS.warning,
          CHART_COLORS.success,
        ],
      },
    ],
  },
};

export const BAR_CHART_DATA = {
  labels: ["Smartphone", "Laptop", "Coffee", "Mouse", "Running Shoes"],
  datasets: [
    {
      label: "Retention",
      data: [5000, 6000, 3000, 4000, 10000],
      backgroundColor: CHART_COLORS.orange,
    },
    {
      label: "Revenue", 
      data: [2500, 3500, 2000, 3000, 7500],
      backgroundColor: CHART_COLORS.blue,
    },
    {
      label: "Profit",
      data: [2000, 2500, 1500, 2000, 5000],
      backgroundColor: CHART_COLORS.green,
    },
  ],
};

export const CHART_OPTIONS = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: true,
      position: "top",
    },
  },
};

export const LINE_CHART_OPTIONS = {
  ...CHART_OPTIONS,
  plugins: {
    legend: { display: false },
  },
};

export const BAR_CHART_OPTIONS = {
  ...CHART_OPTIONS,
  plugins: {
    legend: { position: "top" },
    title: { 
      display: true, 
      text: "Business Performance",
      color: "#fff"
    },
  },
};