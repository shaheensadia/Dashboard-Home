import React from "react";
import { Card } from "react-bootstrap";

const StatsCard = ({ title, value, icon, className = "" }) => {
  return (
    <Card className={`bg-dark text-white text-center border-secondary ${className}`}>
      <Card.Body className="p-4">
        {icon && (
          <div className="mb-2 text-primary fs-3">
            {icon}
          </div>
        )}
        <Card.Title className="mb-2 text-light fs-6 fw-normal">
          {title}
        </Card.Title>
        <h3 className="mb-0 text-white fw-bold">
          {value}
        </h3>
      </Card.Body>
    </Card>
  );
};

export default StatsCard;