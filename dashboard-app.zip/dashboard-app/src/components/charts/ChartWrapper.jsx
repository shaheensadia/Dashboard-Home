import React from "react";
import { Card, CardBody } from "react-bootstrap";
import { Bar, Line, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  BarElement,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";

ChartJS.register(
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  BarElement
);

const ChartWrapper = ({ 
  type = "line", 
  data, 
  options = {}, 
  title, 
  height = "315px",
  className = "" 
}) => {
  const renderChart = () => {
    const props = { data, options };
    
    switch (type) {
      case "bar":
        return <Bar {...props} />;
      case "pie":
        return <Pie {...props} />;
      case "line":
      default:
        return <Line {...props} />;
    }
  };

  return (
    <Card className={`bg-dark text-white ${className}`}>
      {title && (
        <Card.Header className="bg-dark border-secondary">
          <Card.Title className="mb-0 text-white">{title}</Card.Title>
        </Card.Header>
      )}
      <CardBody style={{ height }} className="p-3">
        {renderChart()}
      </CardBody>
    </Card>
  );
};

export default ChartWrapper;