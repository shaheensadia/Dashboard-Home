import React from "react";
import { Container } from "react-bootstrap";
import Header from "./Header";
import Sidebar from "./Sidebar";

const Layout = ({ children }) => {
  return (
    <div className="d-flex" style={{ height: "100vh", overflow: "hidden" }}>
      <div style={{ position: "fixed", left: 0, top: 0, bottom: 0, zIndex: 1000 }}>
        <Sidebar />
      </div>
      <div 
        className="flex-grow-1 bg-black text-white d-flex flex-column" 
        style={{ marginLeft: "80px" }}
      >
        <div style={{ position: "sticky", top: 0, zIndex: 999 }} className="bg-black">
          <Container fluid className="p-4 pb-0">
            <Header />
          </Container>
        </div>
        <div 
          className="flex-grow-1" 
          style={{ overflowY: "auto", overflowX: "hidden" }}
        >
          <Container fluid className="p-4 pt-0">
            <main>{children}</main>
          </Container>
        </div>
      </div>
    </div>
  );
};

export default Layout;