import React from "react";
import {
  BagHeart,
  Cart,
  House,
  List,
  PlusLg,
} from "react-bootstrap-icons";

const Sidebar = () => {
  const menuItems = [
    { icon: <List />, label: "Menu" },
    { icon: <House />, label: "Home" },
    { icon: <BagHeart />, label: "Products" },
    { icon: <PlusLg />, label: "Add" },
    { icon: <Cart />, label: "Cart" },
  ];

  return (
    <div className="bg-dark text-white" style={{ width: "80px", height: "100vh" }}>
      <div className="d-flex flex-column align-items-center py-3">
        {menuItems.map((item, index) => (
          <div
            key={index}
            className="d-flex align-items-center justify-content-center my-3 sidebar-item"
            style={{ 
              cursor: "pointer",
              width: "50px",
              height: "50px",
              borderRadius: "12px",
              transition: "all 0.3s ease"
            }}
            title={item.label}
          >
            <span className="fs-4">{item.icon}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Sidebar;