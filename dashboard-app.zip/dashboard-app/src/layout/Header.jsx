import React from "react";
import { Row, Col } from "react-bootstrap";
import { Bell } from "react-bootstrap-icons";

const Header = () => {
  return (
    <Row className="mb-4 align-items-center bg-dark p-3 mx-1" style={{ borderRadius: "12px" }}>
      <Col>
        <h3 className="mb-0 text-white">Dashboard</h3>
      </Col>
      <Col xs="auto" className="d-flex align-items-center">
        <span className="me-3 text-white">🌐</span>
        <span className="me-3 text-white">
          <Bell size={20} />
        </span>
        <span className="text-white">Sadia Shaheen</span>
      </Col>
    </Row>
  );
};

export default Header;