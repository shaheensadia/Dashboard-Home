import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import ChartWrapper from "../components/charts/ChartWrapper";
import StatsCard from "../components/cards/StatsCard";
import {
  STATS_DATA,
  LINE_CHART_DATA,
  PIE_CHART_DATA,
  BAR_CHART_DATA,
  LINE_CHART_OPTIONS,
  CHART_OPTIONS,
  BAR_CHART_OPTIONS,
} from "../constants/chartData";

const Home = () => {
  return (
    <Container fluid>
      <Row className="mb-4">
        {STATS_DATA.map((stat, index) => (
          <Col md={3} key={index} className="mb-3">
            <StatsCard title={stat.title} value={stat.value} />
          </Col>
        ))}
      </Row>

      <Row className="mb-4">
        <Col md={6} className="mb-3">
          <ChartWrapper
            type="line"
            data={LINE_CHART_DATA}
            options={LINE_CHART_OPTIONS}
            title="Sales Overview"
          />
        </Col>
        <Col md={6} className="mb-3">
          <ChartWrapper
            type="pie"
            data={PIE_CHART_DATA.categoryDistribution}
            options={CHART_OPTIONS}
            title="Category Distribution"
          />
        </Col>
      </Row>

      <Row>
        <Col md={6} className="mb-3">
          <ChartWrapper
            type="pie"
            data={PIE_CHART_DATA.orderStatus}
            options={CHART_OPTIONS}
            title="Order Status Distribution"
          />
        </Col>
        <Col md={6} className="mb-3">
          <ChartWrapper
            type="bar"
            data={BAR_CHART_DATA}
            options={BAR_CHART_OPTIONS}
            title="Product Performance"
          />
        </Col>
      </Row>
    </Container>
  );
};

export default Home;